function goToLanguage() {
  window.location.href = "language.html";
}