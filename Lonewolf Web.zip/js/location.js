const stateCityMap = { en: { "Andaman and Nicobar Islands": ["Port Blair"], "Andhra Pradesh": ["Amaravati", "Visakhapatnam", "Vijayawada"], "Arunachal Pradesh": ["Itanagar", "Tawang"], "Assam": ["Guwahati", "Dibrugarh", "Silchar", "Tezpur"], "Bihar": ["Patna", "Gaya", "Muzaffarpur"], "Chandigarh": ["Chandigarh"], "Chhattisgarh": ["Raipur", "Bilaspur", "Durg"], "Dadra and Nagar Haveli and Daman and Diu": ["Daman", "Silvassa"], "Delhi": ["New Delhi"], "Goa": ["Panaji", "Margao", "Vasco da Gama"], "Gujarat": ["Ahmedabad", "Surat", "Vadodara"], "Haryana": ["Chandigarh", "Gurgaon", "Faridabad"], "Himachal Pradesh": ["Shimla", "Dharamshala"], "Jammu and Kashmir": ["Srinagar", "Jammu"], "Jharkhand": ["Ranchi", "Jamshedpur"], "Karnataka": ["Bengaluru", "Mysore", "Mangalore"], "Kerala": ["Thiruvananthapuram", "Kochi", "Kozhikode"], "Ladakh": ["Leh"], "Lakshadweep": ["Kavaratti"], "Madhya Pradesh": ["Bhopal", "Indore", "Gwalior"], "Maharashtra": ["Mumbai", "Pune", "Nagpur"], "Manipur": ["Imphal"], "Meghalaya": ["Shillong"], "Mizoram": ["Aizawl"], "Nagaland": ["Kohima"], "Odisha": ["Bhubaneswar", "Cuttack"], "Puducherry": ["Puducherry"], "Punjab": ["Chandigarh", "Ludhiana", "Amritsar"], "Rajasthan": ["Jaipur", "Jodhpur", "Udaipur"], "Sikkim": ["Gangtok"], "Tamil Nadu": ["Chennai", "Coimbatore"], "Telangana": ["Hyderabad", "Warangal"], "Tripura": ["Agartala"], "Uttar Pradesh": ["Lucknow", "Kanpur", "Allahabad", "Varanasi", "Fatehpur"], "Uttarakhand": ["Dehradun", "Haridwar"], "West Bengal": ["Kolkata", "Siliguri", "Asansol"] },

hi: { "आंध्र प्रदेश": ["अमरावती", "विशाखापट्टनम", "विजयवाड़ा"], "अरुणाचल प्रदेश": ["इटानगर", "तवांग"], "असम": ["गुवाहाटी", "डिब्रूगढ़", "सिलचर", "तेजपुर"], "आंदमान और निकोबार द्वीप समूह": ["पोर्ट ब्लेयर"], "उत्तर प्रदेश": ["लखनऊ", "कानपुर", "इलाहाबाद", "वाराणसी", "फतेहपुर"], "उत्तराखंड": ["देहरादून", "हरिद्वार"], "ओडिशा": ["भुवनेश्वर", "कटक"], "कर्नाटक": ["बेंगलुरु", "मैसूर", "मैंगलोर"], "केरल": ["तिरुवनंतपुरम", "कोच्चि", "कोझिकोड"], "गोवा": ["पणजी", "मार्गाओ", "वास्को दा गामा"], "गुजरात": ["अहमदाबाद", "सूरत", "वडोदरा"], "छत्तीसगढ़": ["रायपुर", "बिलासपुर", "दुर्ग"], "चंडीगढ़": ["चंडीगढ़"], "झारखंड": ["रांची", "जमशेदपुर"], "जम्मू और कश्मीर": ["श्रीनगर", "जम्मू"], "दिल्ली": ["नई दिल्ली"], "दादरा नगर हवेली और दमन और दीव": ["दमन", "सिलवासा"], "तमिलनाडु": ["चेन्नई", "कोयंबटूर"], "तेलंगाना": ["हैदराबाद", "वारंगल"], "त्रिपुरा": ["अगरतला"], "नागालैंड": ["कोहिमा"], "पंजाब": ["चंडीगढ़", "लुधियाना", "अमृतसर"], "पश्चिम बंगाल": ["कोलकाता", "शिलिगुड़ी", "आसनसोल"], "पुदुच्चेरी": ["पुदुच्चेरी"], "बिहार": ["पटना", "गया", "मुज़फ़्फरपुर"], "मध्य प्रदेश": ["भोपाल", "इंदौर", "ग्वालियर"], "महाराष्ट्र": ["मुंबई", "पुणे", "नागपुर"], "मणिपुर": ["इम्फाल"], "मेघालय": ["शिलांग"], "मिजोरम": ["आइजोल"], "राजस्थान": ["जयपुर", "जोधपुर", "उदयपुर"], "लक्षद्वीप": ["कवरात्ति"], "लद्दाख": ["लेह"], "सिक्किम": ["गंगटोक"], "हिमाचल प्रदेश": ["शिमला", "धर्मशाला"], "हरियाणा": ["चंडीगढ़", "गुड़गाँव", "फरीदाबाद"] },

ur: { "اتر پردیش": ["لکھنؤ", "کانپور", "الہ آباد", "وارانسی", "فتح پور"], "اترکھنڈ": ["دہرادون", "ہاريدوار"], "اروناچل پردیش": ["اٹانگر", "تاوانگ"], "آندھرا پردیش": ["امرآوتی", "وشاخاپٹنم", "وجیوادا"], "آسام": ["گواہاٹی", "دبرگڑھ", "سلچر", "تیجپور"], "انڈامن و نیکوبار آئلینڈز": ["پورٹ بلئیر"], "اڑیسہ": ["بھوبنیشور", "کتک"], "پنجاب": ["چنڈی گڑھ", "لودھیانہ", "امر تسہر"], "پڈوچری": ["پڈوچری"], "بہار": ["پٹنا", "گیا", "مظفر پور"], "تلنگانہ": ["حیدرآباد", "ورنگل"], "تریپورہ": ["اگرتلا"], "تمل ناڈو": ["چنئی", "کوبی نٹور"], "چنڈی گڑھ": ["چنڈی گڑھ"], "جھارکھنڈ": ["رانچی", "جمشید پور"], "جموں و کشمیر": ["سرینگر", "جموں"], "دہلی": ["نئی دہلی"], "دادرا نگر ہاویلی اور دمن اور دیو": ["دمن", "سلواسا"], "راجستھان": ["جےپور", "جوہ دپور", "اودے پور"], "سکم": ["گنگٹوک"], "گجرات": ["احمدآباد", "سورت", "وادودرا"], "گوا": ["پنجئ", "مارگاؤ", "واسکو دا گاما"], "کرناٹک": ["بنگلور", "میسور", "مینگلور"], "کیرالہ": ["تروونانت پورم", "کوچی", "کوزھی کوڈ"], "لداخ": ["لےہ"], "لکشدیپ": ["کاورتتی"], "مدھیہ پردیش": ["بھوپل", "اندور", "گوالیئر"], "مہاراشٹر": ["ممبئی", "پونے", "نگپور"], "مانی پور": ["امفال"], "میگھالیہ": ["شیلونگ"], "میزورم": ["آئزول"], "ہریانہ": ["چنڈی گڑھ", "گڑگاؤں", "فریدآباد"], "ہماچل پردیش": ["شملہ", "دھرمشالہ"] } };


const translations = {
  en: {
    heading: "Select Your Location",
    country: "India",
    statePH: "Select State",
    cityPH: "Select City",
    serviceYes: "✅ Great! We offer services in ",
    serviceSoon: ".",
    serviceNo: "🙏 Sorry! We do not yet offer services in ",
    serviceNoEnd: " at the moment.",
    next: "Next"
  },
  hi: {
    heading: "अपना स्थान चुनें",
    country: "भारत",
    statePH: "राज्य चुनें",
    cityPH: "शहर चुनें",
    serviceYes: "✅ शानदार! हम ",
    serviceSoon: " में सेवाएं प्रदान करते हैं।",
    serviceNo: "🙏 क्षमा करें! हम अभी ",
    serviceNoEnd: " में सेवाएं प्रदान नहीं करते।",
    next: "आगे बढ़ें"
  },
  ur: {
    heading: "اپنا مقام منتخب کریں",
    country: "بھارت",
    statePH: "ریاست منتخب کریں",
    cityPH: "شہر منتخب کریں",
    serviceYes: "✅ شاندار! ہم ",
    serviceSoon: " میں خدمات فراہم کرتے ہیں۔",
    serviceNo: "🙏 معذرت! ہم ابھی ",
    serviceNoEnd: " میں خدمات فراہم نہیں کرتے۔",
    next: "آگے بڑھیں"
  }
};

let lang = localStorage.getItem("selectedLanguage") || "en";

window.onload = () => {
  const tr = translations[lang];

  // Set Heading
  document.querySelector(".select-heading").innerText = tr.heading;

  // Set Country dropdown
  document.getElementById("country").innerHTML = `<option value="India">${tr.country}</option>`;

  // Set State & City Placeholders
  document.getElementById("state").innerHTML = `<option disabled selected>${tr.statePH}</option>`;
  document.getElementById("city").innerHTML = `<option disabled selected>${tr.cityPH}</option>`;
  
  document.querySelector(".select-heading").innerText = tr.heading;

  // Set "Next" button in modal
  document.querySelector("#serviceModal button").innerText = tr.next;

  buildStates();
};

function buildStates(){
  const stSel = document.getElementById("state");
  stSel.innerHTML = `<option disabled selected>${translations[lang].statePH}</option>`;
  Object.keys(stateCityMap[lang]).forEach(st => {
    const o = document.createElement("option");
    o.value = o.textContent = st;
    stSel.appendChild(o);
  });
}

function updateCities(){
  const state = document.getElementById("state").value;
  const citySel = document.getElementById("city");
  citySel.innerHTML = `<option disabled selected>${translations[lang].cityPH}</option>`;

  stateCityMap[lang][state].forEach(city => {
    const o = document.createElement("option");
    o.value = o.textContent = city;
    citySel.appendChild(o);
  });

  document.getElementById("message").innerText = "";
}


const supportedCitiesMultiLang = [
  "Lucknow", "Allahabad", "Fatehpur",       // English
  "लखनऊ", "इलाहाबाद", "फतेहपुर",             // Hindi
  "لکھنؤ", "الہ آباد", "فتح پور"              // Urdu
];

function checkService() {
  const city = document.getElementById("city").value;
  const msg = document.getElementById("message");
  const loader = document.getElementById("loader");
  const modal = document.getElementById("serviceModal");
  const modalText = document.getElementById("modalText");

  msg.innerText = "";
  loader.style.display = "block";

  setTimeout(() => {
    loader.style.display = "none";

    if (supportedCitiesMultiLang.includes(city)) {
      const message = translations[lang].serviceYes + city + translations[lang].serviceSoon;
      modalText.innerText = message;
      modal.style.display = "block";
      setTimeout(() => {
        modal.style.display = "none";
        window.location.href = "services.html";
      }, 2500);
    } else {
      const message = translations[lang].serviceNo + city + translations[lang].serviceNoEnd;
      typeText(msg, message);
    }
  }, 1200);
}

function toEnglish(local){
  if (lang === "en") return local;

  const localStates = Object.keys(stateCityMap[lang]);
  const enStates = Object.keys(stateCityMap["en"]);

  for (let i = 0; i < localStates.length; i++) {
    const localCities = stateCityMap[lang][localStates[i]];
    const index = localCities.indexOf(local);
    if (index !== -1) {
      const enState = enStates[i];
      const enCities = stateCityMap["en"][enState];
      const englishCity = enCities[index];
      return englishCity;
    }
  }

  return local;
}

function typeText(element, text, delay = 30) {
  element.innerText = "";
  let i = 0;
  const type = () => {
    if (i < text.length) {
      element.innerText += text.charAt(i);
      i++;
      setTimeout(type, delay);
    }
  };
  type();
}

function closeModal() {
  document.getElementById("serviceModal").style.display = "none";
  window.location.href = "services.html";
}

function goBack() {
  window.history.back();
}