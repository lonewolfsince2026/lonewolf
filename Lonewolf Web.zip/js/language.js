function selectLanguage(lang) {
  // Language value can be used in future
  // For now just go to next page
  localStorage.setItem('selectedLanguage', lang);
  window.location.href = "location.html";
}